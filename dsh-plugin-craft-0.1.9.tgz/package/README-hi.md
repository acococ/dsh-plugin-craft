# dsh-plugin-craft

DSH Plugin Workshop — DeepSeek Harness (DSH) प्लगइन बनाने के लिए पाँच-चरण का निर्देशित प्रवाह, केवल चरण 1, 2 और डिलीवरी पृष्ठ पर उपयोगकर्ता के गेट के साथ।

## Compatibility

| सतह | स्थिति |
|---|---|
| Harness | DeepSeek Harness `0.1.7-rc.2` |
| Node | `^22.19.0 \|\| >=24.0.0` |
| प्लेटफ़ॉर्म | सभी (शुद्ध ESM; कोई नेटिव कोड नहीं, इंस्टॉल के समय कोई नेटवर्क नहीं) |

## What it does

Workshop "मैं एक DSH प्लगइन लिखना चाहता हूँ" को पाँच-चरणीय निर्देशित प्रवाह में बदल देता है:

1. **इंटरव्यू** — अस्पष्ट विचारों को संरचित आवश्यकता-विशिष्टता में कैद करना (उपयोगकर्ता गेट)।
2. **डिज़ाइन** — मॉड्यूल सीमाएँ, प्रमुख इंटरफ़ेस, और `cordis.patch.yml` कंकाल (उपयोगकर्ता गेट)।
3. **कार्य** — काम को `dsh-agent-teams` DAG में विभाजित करना (स्वचालित)।
4. **कोड उत्पन्न करना** — `dsh-agent-teams` टीम के माध्यम से प्लगइन लागू करना (स्वचालित)।
5. **सत्यापन** — `dsh-plugin-dev check --strict` और `dsh-plugin-dev verify` चलाना, फिर आवश्यकता-कवरेज पास (स्वचालित, अधिकतम तीन पुनः प्रयास)।

जब चरण 5 पास होता है, तो उपयोगकर्ता डिलीवरी पृष्ठ पर पहुँचता है और तय करता है कि परिणाम को वर्तमान प्रोफ़ाइल में स्थापित करना है या नहीं (डिफ़ॉल्ट: नहीं — स्थापना के लिए स्पष्ट अधिकृत आवश्यक है)।

प्लगइन जोड़ता है:

- Web UI की साइडबार में एक नई प्रविष्टि "插件工坊" / "Workshop"।
- एक नया पूर्ण-पृष्ठ पैनल जो प्रोजेक्ट सूचीबद्ध करता है और चरण पट्टी + प्रति-चरण दृश्य प्रस्तुत करता है।
- दो Chat-साइड टूल: `craft.create_project` और `craft.advance_stage`।

## Where projects live

हर प्रोजेक्ट `projectsDir/<plugin-name>/project.json` के अंतर्गत एक निर्देशिका है (डिफ़ॉल्ट `projects/dsh-plugin-craft/<plugin-name>/`)। डिफ़ॉल्ट पथ `$DSH_HOME` के सापेक्ष है। अपनी प्रोफ़ाइल के `cordis.patch.yml` में किसी भी कुंजी को ओवरराइड करें:

```yaml
- id: dsh-plugin-craft
  config:
    projectsDir: D:/my-projects/workshop
    maxListedProjects: 100
```

`maxListedProjects` UI सूची को सीमित करता है; पुराने प्रोजेक्ट डिस्क पर बने रहते हैं।

## Install

```sh
pnpm pack
dsh plugin --profile web add ./dsh-plugin-craft-0.1.0.tgz
dsh --profile web --dump-config | grep 'dsh-plugin-craft'
```

फिर `dsh --profile web` को पुनः आरंभ करें। Workshop पैनल साइडबार में दिखाई देगा।

## Configuration

| कुंजी | प्रकार | डिफ़ॉल्ट | विवरण |
|---|---|---|---|
| `projectsDir` | string | `projects/dsh-plugin-craft` | Workshop प्रोजेक्ट निर्देशिका; `$DSH_HOME` के सापेक्ष, जब तक कि निरपेक्ष न हो। |
| `maxListedProjects` | number | `50` | UI में सूचीबद्ध प्रोजेक्ट की सीमा; पुराने डिस्क पर बने रहते हैं। |

कॉन्फ़िगरेशन `src/config.ts` में Schemastery `Config` स्कीमा से मान्य होता है; कोई भी सेटिंग हार्डकोडेड नहीं है।

## Chat-side tools

### `craft.create_project`

Chat से एक नया Workshop प्रोजेक्ट खोलें।

| पैरामीटर | प्रकार | आवश्यक | विवरण |
|---|---|---|---|
| `pluginName` | string | हाँ | प्लगइन id (छोटे अक्षर), जैसे `device-scanner`। |
| `fuzzyIdea` | string | हाँ | एक पंक्ति में विचार कि प्लगइन को क्या करना चाहिए। |

### `craft.advance_stage`

Chat से एक चरण को स्वीकार या संशोधित करें।

| पैरामीटर | प्रकार | आवश्यक | विवरण |
|---|---|---|---|
| `pluginName` | string | हाँ | प्रोजेक्ट का id। |
| `decision` | string | हाँ | `accept` (आगे बढ़ें) या `revise` (रुकें)। |
| `feedback` | string | नहीं | संशोधन के लिए वैकल्पिक प्रतिक्रिया। |

## Development

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
```

`pnpm run build` `lib/index.mjs` (Host), `lib/client.mjs` (ब्राउज़र) और उनके `.d.mts` साथी `tsdown` के माध्यम से उत्पन्न करता है।

## Plugin architecture

| आधा | कहाँ | उद्देश्य |
|---|---|---|
| Host | `src/index.ts`, `src/store.ts` | `CraftStore` (स्थायित्व) + `CraftBridgeService` (Client-सामने Remote) + दो Chat टूल। |
| Client | `src/client.ts` | `sidebar.panellist` (आइकन) और `main` (पूर्ण Workshop पृष्ठ) पंजीकृत करता है। |

`cordis.patch.yml` Host पंक्ति को माउंट करता है; `package.json` का `dsh.client` ब्लॉक Client बंडल को माउंट करता है। Client `ctx.craftBridge` के माध्यम से Host तक पहुँचता है (declaration merging द्वारा घोषित)।

## Safety boundary

Workshop वर्तमान प्रोफ़ाइल में उत्पन्न प्लगइन को **कभी स्थापित नहीं करता**। डिलीवरेबल डिस्क पर प्रोजेक्ट ट्री है। स्थापना के लिए उपयोगकर्ता की अलग अधिकृत आवश्यक है (इस प्लगइन के दायरे से बाहर)।

## License

[Apache License 2.0](LICENSE) © 2026 dsh-plugin-craft contributors.