# dsh-plugin-craft

DSH 插件工坊 —— 把"开发一个 DSH 插件"变成五阶段引导流程，只在阶段 1、阶段 2 和交付页需要用户把关。

## Compatibility

| 项 | 状态 |
|---|---|
| Harness | DeepSeek Harness `0.1.7-rc.2` |
| Node | `^22.19.0 \|\| >=24.0.0` |
| 平台 | 全部（纯 ESM；无原生代码，安装时无网络） |

## What it does

工坊把"我想写一个 DSH 插件"拆成五个阶段：

1. **采访** —— 把模糊想法整理成结构化的需求规格（用户把关）。
2. **设计** —— 写出模块划分、关键接口、`cordis.patch.yml` 骨架（用户把关）。
3. **拆任务** —— 把工作拆成 agent-teams 可调度的 DAG（自动跑）。
4. **生成代码** —— 由 `dsh-agent-teams` 团队并行实现（自动跑）。
5. **检查上线** —— 跑 `dsh-plugin-dev check --strict` 和 `dsh-plugin-dev verify`，再做一轮需求覆盖核验（自动跑，最多三轮）。

阶段 5 通过后跳到交付页，由用户决定是否把产物 install 到当前 profile（默认不 install，需用户单独授权）。

插件新增：

- Web UI 侧边栏多一个「插件工坊」图标。
- 一个独立的全页面面板，展示项目列表 + 阶段进度条 + 各阶段视图。
- 两个 Chat 工具：`craft.create_project` 和 `craft.advance_stage`。

## Where projects live

每个项目是 `projectsDir/<plugin-name>/project.json`（默认 `projects/dsh-plugin-craft/<plugin-name>/`）。默认路径相对于 `$DSH_HOME`；可在 profile 的 `cordis.patch.yml` 里覆盖：

```yaml
- id: dsh-plugin-craft
  config:
    projectsDir: D:/my-projects/workshop
    maxListedProjects: 100
```

`maxListedProjects` 仅限制 UI 列表数量，更早的项目仍保留在磁盘上。

## Install

```sh
pnpm pack
dsh plugin --profile web add ./dsh-plugin-craft-0.1.0.tgz
dsh --profile web --dump-config | grep 'dsh-plugin-craft'
```

然后重启 `dsh --profile web`，侧边栏就会出现「插件工坊」。

## Configuration

| 键 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `projectsDir` | string | `projects/dsh-plugin-craft` | 存放工坊项目的目录；相对 `$DSH_HOME`，绝对路径则原样使用。 |
| `maxListedProjects` | number | `50` | UI 列表中显示的项目上限；旧项目不会被删除。 |

配置由 `src/config.ts` 中的 Schemastery `Config` schema 校验；没有任何硬编码可调参数。

## Chat-side tools

### `craft.create_project`

从 Chat 创建一个新的工坊项目。

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `pluginName` | string | 是 | 小写 plugin id，例如 `device-scanner`。 |
| `fuzzyIdea` | string | 是 | 用户视角的一句话描述。 |

### `craft.advance_stage`

从 Chat 接受或驳回当前阶段。

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `pluginName` | string | 是 | 项目 plugin id。 |
| `decision` | string | 是 | `accept`（前进）或 `revise`（留在原阶段）。 |
| `feedback` | string | 否 | 驳回时的反馈文本。 |

## Development

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
```

`pnpm run build` 通过 `tsdown` 生成 `lib/index.mjs`（Host）、`lib/client.mjs`（浏览器）和对应的 `.d.mts`。

## Plugin architecture

| 端 | 位置 | 作用 |
|---|---|---|
| Host | `src/index.ts`、`src/store.ts` | `CraftStore`（持久化）+ `CraftBridgeService`（Client 端 Remote）+ 两个 Chat 工具。 |
| Client | `src/client.ts` | 注册 `sidebar.panellist`（图标）和 `main`（完整工坊页面）。 |

`cordis.patch.yml` 挂载 Host 行；`package.json` 的 `dsh.client` 块挂载 Client bundle。Client 通过 `ctx.craftBridge` 调到 Host（经 declaration merging）。

## Safety boundary

工坊**绝不会**自动 install 生成的插件。交付物只是磁盘上的项目目录，是否 install 需要用户单独授权（不在本插件范围内）。

## License

[Apache License 2.0](LICENSE) © 2026 dsh-plugin-craft contributors.