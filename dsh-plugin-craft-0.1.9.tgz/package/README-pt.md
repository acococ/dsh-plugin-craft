# dsh-plugin-craft

DSH Plugin Workshop — um fluxo guiado de cinco etapas para construir plugins do DeepSeek Harness (DSH), com portões do usuário apenas nas etapas 1, 2 e na página de entrega.

## Compatibility

| Superfície | Estado |
|---|---|
| Harness | DeepSeek Harness `0.1.7-rc.2` |
| Node | `^22.19.0 \|\| >=24.0.0` |
| Plataformas | Todas (ESM puro; sem código nativo, sem rede na instalação) |

## What it does

O Workshop transforma "quero escrever um plugin DSH" em um fluxo guiado de cinco etapas:

1. **Entrevista** — captura ideias vagas em uma especificação estruturada (portão do usuário).
2. **Design** — esboça fronteiras de módulos, interfaces-chave e o esqueleto do `cordis.patch.yml` (portão do usuário).
3. **Tarefas** — divide o trabalho em um DAG para o `dsh-agent-teams` (auto).
4. **Gerar** — implementa o plugin pela equipe `dsh-agent-teams` (auto).
5. **Verificar** — roda `dsh-plugin-dev check --strict` e `dsh-plugin-dev verify`, depois uma passada de cobertura de requisitos (auto, até três tentativas).

Quando a etapa 5 passa, o usuário cai na página de entrega e decide se instala o resultado no perfil atual (padrão: não — a instalação exige autorização explícita).

O plugin adiciona:

- Uma nova entrada "插件工坊" / "Workshop" na barra lateral da Web UI.
- Um novo painel de página completa que lista projetos e mostra a faixa de etapas + a visão por etapa.
- Duas ferramentas de Chat: `craft.create_project` e `craft.advance_stage`.

## Where projects live

Cada projeto é um diretório em `projectsDir/<plugin-name>/project.json` (padrão `projects/dsh-plugin-craft/<plugin-name>/`). O caminho padrão é relativo a `$DSH_HOME`. Substitua qualquer chave no `cordis.patch.yml` do seu perfil:

```yaml
- id: dsh-plugin-craft
  config:
    projectsDir: D:/my-projects/workshop
    maxListedProjects: 100
```

`maxListedProjects` limita a listagem da UI; projetos antigos permanecem em disco.

## Install

```sh
pnpm pack
dsh plugin --profile web add ./dsh-plugin-craft-0.1.0.tgz
dsh --profile web --dump-config | grep 'dsh-plugin-craft'
```

Em seguida, reinicie `dsh --profile web`. O painel do Workshop aparece na barra lateral.

## Configuration

| Chave | Tipo | Padrão | Descrição |
|---|---|---|---|
| `projectsDir` | string | `projects/dsh-plugin-craft` | Diretório dos projetos do Workshop; resolvido em relação a `$DSH_HOME`, salvo se absoluto. |
| `maxListedProjects` | number | `50` | Limite de projetos listados na UI antes dos antigos saírem da lista. |

A configuração é validada pelo schema Schemastery `Config` em `src/config.ts`; nenhum ajuste fica fixo no código.

## Chat-side tools

### `craft.create_project`

Abre um novo projeto do Workshop pelo Chat.

| Parâmetro | Tipo | Obrigatório | Descrição |
|---|---|---|---|
| `pluginName` | string | sim | id em minúsculas do plugin, ex.: `device-scanner`. |
| `fuzzyIdea` | string | sim | A ideia em uma linha sobre o que o plugin deve fazer. |

### `craft.advance_stage`

Aceita ou revisa uma etapa pelo Chat.

| Parâmetro | Tipo | Obrigatório | Descrição |
|---|---|---|---|
| `pluginName` | string | sim | id do projeto. |
| `decision` | string | sim | `accept` (avançar) ou `revise` (permanecer). |
| `feedback` | string | não | Comentário opcional para a revisão. |

## Development

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
```

`pnpm run build` produz `lib/index.mjs` (Host), `lib/client.mjs` (navegador) e seus `.d.mts` via `tsdown`.

## Plugin architecture

| Metade | Onde | Propósito |
|---|---|---|
| Host | `src/index.ts`, `src/store.ts` | `CraftStore` (persistência) + `CraftBridgeService` (Remoto para o Client) + duas ferramentas de Chat. |
| Client | `src/client.ts` | Registra `sidebar.panellist` (ícone) e `main` (página completa do Workshop). |

`cordis.patch.yml` monta a linha Host; o bloco `dsh.client` em `package.json` monta o bundle do Client. O Client alcança o Host via `ctx.craftBridge` (declarado por declaration merging).

## Safety boundary

O Workshop **nunca instala** o plugin produzido no perfil atual. O entregável é a árvore de projeto em disco. A instalação exige uma autorização separada do usuário (fora do escopo deste plugin).

## License

[Apache License 2.0](LICENSE) © 2026 dsh-plugin-craft contributors.