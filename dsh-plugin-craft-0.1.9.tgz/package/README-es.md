# dsh-plugin-craft

DSH Plugin Workshop — un flujo guiado de cinco etapas para construir plugins de DeepSeek Harness (DSH), con puertas de usuario solo en las etapas 1, 2 y la página de entrega.

## Compatibility

| Superficie | Estado |
|---|---|
| Harness | DeepSeek Harness `0.1.7-rc.2` |
| Node | `^22.19.0 \|\| >=24.0.0` |
| Plataformas | Todas (ESM puro; sin código nativo, sin red en la instalación) |

## What it does

El Workshop convierte "quiero escribir un plugin DSH" en un flujo guiado de cinco etapas:

1. **Entrevista** — captura ideas difusas en una especificación estructurada (puerta del usuario).
2. **Diseño** — esboza los límites de los módulos, las interfaces clave y el esqueleto de `cordis.patch.yml` (puerta del usuario).
3. **Tareas** — divide el trabajo en un DAG para `dsh-agent-teams` (auto).
4. **Generar** — implementa el plugin a través del equipo `dsh-agent-teams` (auto).
5. **Verificar** — ejecuta `dsh-plugin-dev check --strict` y `dsh-plugin-dev verify`, luego una pasada de cobertura de requisitos (auto, hasta tres reintentos).

Cuando la etapa 5 pasa, el usuario llega a la página de entrega y decide si instala el resultado en el perfil actual (por defecto: no — la instalación requiere autorización explícita).

El plugin añade:

- Una nueva entrada "插件工坊" / "Workshop" en la barra lateral de la Web UI.
- Un nuevo panel de página completa que lista proyectos y muestra la tira de etapas + vista por etapa.
- Dos herramientas de Chat: `craft.create_project` y `craft.advance_stage`.

## Where projects live

Cada proyecto es un directorio en `projectsDir/<plugin-name>/project.json` (por defecto `projects/dsh-plugin-craft/<plugin-name>/`). La ruta por defecto es relativa a `$DSH_HOME`. Sobrescribe cualquier clave en el `cordis.patch.yml` de tu perfil:

```yaml
- id: dsh-plugin-craft
  config:
    projectsDir: D:/my-projects/workshop
    maxListedProjects: 100
```

`maxListedProjects` limita el listado de la UI; los proyectos más viejos permanecen en disco.

## Install

```sh
pnpm pack
dsh plugin --profile web add ./dsh-plugin-craft-0.1.0.tgz
dsh --profile web --dump-config | grep 'dsh-plugin-craft'
```

Luego reinicia `dsh --profile web`. El panel del Workshop aparece en la barra lateral.

## Configuration

| Clave | Tipo | Valor por defecto | Descripción |
|---|---|---|---|
| `projectsDir` | string | `projects/dsh-plugin-craft` | Directorio de proyectos del Workshop; se resuelve relativo a `$DSH_HOME` salvo que sea absoluto. |
| `maxListedProjects` | number | `50` | Límite de proyectos retenidos en el listado de la UI; los antiguos se conservan en disco. |

La configuración se valida con el esquema Schemastery `Config` en `src/config.ts`; ningún ajuste está codificado.

## Chat-side tools

### `craft.create_project`

Abre un nuevo proyecto del Workshop desde Chat.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---|---|
| `pluginName` | string | sí | id en minúsculas del plugin, p. ej. `device-scanner`. |
| `fuzzyIdea` | string | sí | La idea en una línea que describe qué debe hacer el plugin. |

### `craft.advance_stage`

Acepta o revisa una etapa desde Chat.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---|---|
| `pluginName` | string | sí | El id del proyecto. |
| `decision` | string | sí | `accept` (avanzar) o `revise` (quedarse). |
| `feedback` | string | no | Comentario opcional para la revisión. |

## Development

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
```

`pnpm run build` produce `lib/index.mjs` (Host), `lib/client.mjs` (navegador) y sus `.d.mts` compañeros mediante `tsdown`.

## Plugin architecture

| Mitad | Dónde | Propósito |
|---|---|---|
| Host | `src/index.ts`, `src/store.ts` | `CraftStore` (persistencia) + `CraftBridgeService` (Remoto hacia el Client) + dos herramientas de Chat. |
| Client | `src/client.ts` | Registra `sidebar.panellist` (icono) y `main` (página completa del Workshop). |

`cordis.patch.yml` monta la fila Host; el bloque `dsh.client` del `package.json` monta el bundle del Client. El Client llega al Host mediante `ctx.craftBridge` (declarado por declaration merging).

## Safety boundary

El Workshop **nunca instala** el plugin producido en el perfil actual. El entregable es el árbol del proyecto en disco. La instalación requiere una autorización separada del usuario (fuera del alcance de este plugin).

## License

[Apache License 2.0](LICENSE) © 2026 dsh-plugin-craft contributors.