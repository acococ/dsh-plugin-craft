# dsh-plugin-craft

DSH Plugin Workshop — a five-stage guided flow for building DeepSeek Harness (DSH) plugins, with user gates only at stages 1, 2, and the delivery page.

## Compatibility

| Surface | Status |
|---|---|
| Harness | DeepSeek Harness `0.1.7-rc.2` |
| Node | `^22.19.0 \|\| >=24.0.0` |
| Platforms | All (pure ESM; no native code, no network at install time) |

## What it does

The Workshop turns "I want to write a DSH plugin" into a guided five-stage flow:

1. **Interview** — capture fuzzy ideas into a structured requirements spec (user gate).
2. **Design** — sketch module boundaries, key interfaces, and the `cordis.patch.yml` skeleton (user gate).
3. **Tasks** — split the work into an agent-teams DAG (auto).
4. **Generate** — implement the plugin through the `dsh-agent-teams` crew (auto).
5. **Verify** — run `dsh-plugin-dev check --strict` and `dsh-plugin-dev verify`, then a requirement-coverage pass (auto, up to three retries).

When stage 5 passes, the user lands on the delivery page and decides whether to install the result into the current profile (default: no — install requires explicit user authorization).

The plugin adds:

- A new sidebar entry "插件工坊" / "Workshop" in the Web UI.
- A new full-page panel that lists projects and renders the stage strip + per-stage view.
- Two Chat-side tools: `craft.create_project` and `craft.advance_stage`.

## Where projects live

Every project is a directory under `projectsDir/<plugin-name>/project.json` (default: `projects/dsh-plugin-craft/<plugin-name>/`). The default path is relative to `$DSH_HOME`. Override either key in your profile's `cordis.patch.yml`:

```yaml
- id: dsh-plugin-craft
  config:
    projectsDir: D:/my-projects/workshop
    maxListedProjects: 100
```

`maxListedProjects` caps the UI listing; older projects stay on disk.

## Install

```sh
pnpm pack
dsh plugin --profile web add ./dsh-plugin-craft-0.1.0.tgz
dsh --profile web --dump-config | grep 'dsh-plugin-craft'
```

Then restart `dsh --profile web`. The Workshop panel appears in the sidebar.

## Configuration

| Key | Type | Default | Description |
|---|---|---|---|
| `projectsDir` | string | `projects/dsh-plugin-craft` | Directory holding workshop projects; resolved relative to `$DSH_HOME` unless absolute. |
| `maxListedProjects` | number | `50` | Cap on auto-retained projects listed in the UI before older ones roll off. |

Configuration is validated by the Schemastery `Config` schema in `src/config.ts`; no tunable is hardcoded.

## Chat-side tools

### `craft.create_project`

Open a new Workshop project from Chat.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `pluginName` | string | yes | Lowercase plugin id, e.g. `device-scanner`. |
| `fuzzyIdea` | string | yes | The user-facing one-liner describing what the plugin should do. |

### `craft.advance_stage`

Accept or revise a Workshop stage from Chat.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `pluginName` | string | yes | The project's plugin id. |
| `decision` | string | yes | `accept` (advance) or `revise` (stay). |
| `feedback` | string | no | Optional revision feedback. |

## Development

```sh
pnpm install
pnpm run typecheck
pnpm test
pnpm run build
```

`pnpm run build` produces `lib/index.js` (host), `lib/client.js` (browser), and their `.d.ts` companions via `tsdown`.

## Plugin architecture

| Half | Where | Purpose |
|---|---|---|
| Host | `src/index.ts`, `src/store.ts` | `CraftStoreService` (persistence) + `CraftBridgeService` (Client-facing Remote) + two Chat tools. |
| Client | `src/client.ts` | Registers `sidebar.panellist` (icon) and `main` (full Workshop page). |

`cordis.patch.yml` mounts the Host row; the `package.json` `dsh.client` block mounts the Client bundle. The Client reaches the Host through `ctx.craftBridge` (declared via declaration merging).

## Safety boundary

The Workshop **never installs** the produced plugin into the current profile. The deliverable is the on-disk project tree. Installation requires a separate user authorization (outside this plugin's scope).

## License

[Apache License 2.0](LICENSE) © 2026 dsh-plugin-craft contributors.